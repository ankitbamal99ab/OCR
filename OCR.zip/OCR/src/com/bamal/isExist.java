package com.bamal;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class isExist {
	
    public static boolean exists(String URLName) {
        boolean result = false;
        try {
            InputStream input = (new URL(URLName)).openStream();
            result = true;
        } catch (IOException ex) {
            System.out.println("Image doesnot exits :");
        }
        return result;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuJt434q4EcSeJNvzroX6MCtuoC5qk_o-dXQ&usqp=CAU";
		System.out.print(exists(str));
		
	}

}
