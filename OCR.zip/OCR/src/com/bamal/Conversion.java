package com.bamal;

//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
import org.json.*;  
public class Conversion
{  
public static void main(String[] args) throws JSONException   
{  
String string = "{\"name\": \"Sam Smith\", \"technology\": \"Python\"}"; 
//	String string="[{name : Ankit Bamal}]";
JSONObject json = new JSONObject(string);  
System.out.println(json.toString());  
String technology = json.getString("name");  
System.out.println(technology);  
}  
}