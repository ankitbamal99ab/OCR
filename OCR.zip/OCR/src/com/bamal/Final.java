package com.bamal;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;


import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
//import java.io.IOException;
//import java.io.InputStream;
//import java.net.URL;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class Final {

	
	static void OCR(String str) throws IOException 
	{
        String result="";
        URL url =new URL(str);
        BufferedImage img = ImageIO.read(url);
        
        Tesseract tesseract = new Tesseract(); 
        try { 
  
            tesseract.setDatapath("C:\\Users\\Ankit Bamal\\Downloads\\Tess4J-3.4.8-src\\Tess4J\\tessdata"); 
            tesseract.setLanguage("eng");
            
            // the path of your tess data folder 
            // inside the extracted file 
            
//            tesseract.setLanguage("ind");
//            String text  = tesseract.doOCR(new File("C:\\Users\\Ankit Bamal\\Desktop/image1.jpeg")); 
 
//            String text=tesseract.doOCR(new File(str));

            result=tesseract.doOCR(img);
            // path of your image file 
            System.out.print(result);
        } 
        catch (TesseractException e) { 
            e.printStackTrace(); 
	}
	}
	
    public static boolean exists(String URLName) {
        boolean result = false;
        try {
            InputStream input = (new URL(URLName)).openStream();
            result = true;
        } catch (IOException ex) {
            System.out.println("Image doesnot exits :");
        }
        return result;
    }
    
    public static boolean isValid(String imageUrl) throws IOException, InterruptedException {
        URL url = new URL(imageUrl);
        Image img = ImageIO.read(url);
        //img = img.getScaledInstance(100, -1, Image.SCALE_FAST);
        int w = img.getWidth(null);
        int h = img.getHeight(null);
        int[] pixels = new int[w * h];
        PixelGrabber pg = new PixelGrabber(img, 0, 0, w, h, pixels, 0, w);
        pg.grabPixels();
        boolean isValid = false;
        for (int pixel : pixels) {
            Color color = new Color(pixel);
            if (color.getAlpha() == 0 || color.getRGB() != Color.WHITE.getRGB()) {
                isValid = true;
                break;
            }
        }
        return isValid;
    }
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String url="https://images.unsplash.com/photo-1528459199957-0ff28496a7f6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=682&q=80";
		if(exists(url)) 
		{
			try {
				if(isValid(url)==true) 
				{
					OCR(url);
				}else 
				{
					System.out.println("Image is not Clear");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		String url="https://images.unsplash.com/photo-1592168865720-df6eec2632d9?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxzZWFyY2h8Nzl8fHRleHQlMjBpbWFnZXxlbnwwfHwwfA%3D%3D&auto=format&fit=crop&w=600&q=60";
	}

}
