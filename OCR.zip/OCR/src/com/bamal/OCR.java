package com.bamal;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class OCR {
	static void OCR1(String str) throws IOException 
	{
        String result="";
        URL url =new URL(str);
        BufferedImage img = ImageIO.read(url);
        
        Tesseract tesseract = new Tesseract(); 
        try { 
  
            tesseract.setDatapath("C:\\Users\\Ankit Bamal\\Downloads\\Tess4J-3.4.8-src\\Tess4J\\tessdata"); 
//            tesseract.setLanguage("eng");
            
            // the path of your tess data folder 
            // inside the extracted file 
            
//            tesseract.setLanguage("ind");
//            String text  = tesseract.doOCR(new File("C:\\Users\\Ankit Bamal\\Desktop/image1.jpeg")); 
 
//            String text=tesseract.doOCR(new File(str));

            result=tesseract.doOCR(img);
            // path of your image file 
            System.out.print(result);
        } 
        catch (TesseractException e) { 
            e.printStackTrace(); 
	}
	}
public static void main(String args[]) throws IOException 
{
	String url="https://images.unsplash.com/photo-1592168865720-df6eec2632d9?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxzZWFyY2h8Nzl8fHRleHQlMjBpbWFnZXxlbnwwfHwwfA%3D%3D&auto=format&fit=crop&w=600&q=60";
	OCR1(url);
}
}
